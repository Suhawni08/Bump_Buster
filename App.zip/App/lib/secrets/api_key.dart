const String google_api_key = "AIzaSyDWFYVHjrBqj3jjkCbR2E0esIDHVLnSR3s";
const double defaultPadding = 16.0;
