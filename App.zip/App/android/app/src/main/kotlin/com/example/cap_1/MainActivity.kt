package com.example.cap_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
